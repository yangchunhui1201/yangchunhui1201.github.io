<template>
	<div style="position: relative;height: 28.251851rem;">
		<headers>
			<span slot="tite">微信(<span>54</span>)</span>
			<i class="iconfont" slot="icon1" style="float: right;margin-left: 1.481481rem;">&#xe6ac;</i>
			<i class="iconfont" slot="icon2" style="float: right;">&#xe63a;</i>
		</headers>
		<div class="content">
			<div>
				<news>
					<img src="http://pic3.zhimg.com/50/v2-280218dcc9db1a9108b867bd81b29745_hd.jpg" alt="" slot="user-img">
					<h5 style="font-size: 0.592592rem;line-height: 1.185185rem;" class="clearfix" slot="user-name">刘某 <time style="font-size: 0.414814rem;color: #dadada;float: right;margin-right: 0.666666rem;font-weight: normal;"><span>下午</span><span>4:19</span></time></h5>
					<p style="font-size: 0.503703rem;color: #dadada;line-height: 0.592592rem;" slot="user-news"><span>在干啥？</span></p>
				</news>
				<news>
					<img src="http://pic3.zhimg.com/50/v2-280218dcc9db1a9108b867bd81b29745_hd.jpg" alt="" slot="user-img">
					<h5 style="font-size: 0.592592rem;line-height: 1.185185rem;" class="clearfix" slot="user-name">刘某 <time style="font-size: 0.414814rem;color: #dadada;float: right;margin-right: 0.666666rem;font-weight: normal;"><span>下午</span><span>4:19</span></time></h5>
					<p style="font-size: 0.503703rem;color: #dadada;line-height: 0.592592rem;" slot="user-news"><span>在干啥？</span></p>
				</news>
				<news>
					<img src="http://pic3.zhimg.com/50/v2-280218dcc9db1a9108b867bd81b29745_hd.jpg" alt="" slot="user-img">
					<h5 style="font-size: 0.592592rem;line-height: 1.185185rem;" class="clearfix" slot="user-name">刘某 <time style="font-size: 0.414814rem;color: #dadada;float: right;margin-right: 0.666666rem;font-weight: normal;"><span>下午</span><span>4:19</span></time></h5>
					<p style="font-size: 0.503703rem;color: #dadada;line-height: 0.592592rem;" slot="user-news"><span>在干啥？</span></p>
				</news>
				<news>
					<img src="http://pic3.zhimg.com/50/v2-280218dcc9db1a9108b867bd81b29745_hd.jpg" alt="" slot="user-img">
					<h5 style="font-size: 0.592592rem;line-height: 1.185185rem;" class="clearfix" slot="user-name">刘某 <time style="font-size: 0.414814rem;color: #dadada;float: right;margin-right: 0.666666rem;font-weight: normal;"><span>下午</span><span>4:19</span></time></h5>
					<p style="font-size: 0.503703rem;color: #dadada;line-height: 0.592592rem;" slot="user-news"><span>在干啥？</span></p>
				</news>
				<news>
					<img src="http://pic3.zhimg.com/50/v2-280218dcc9db1a9108b867bd81b29745_hd.jpg" alt="" slot="user-img">
					<h5 style="font-size: 0.592592rem;line-height: 1.185185rem;" class="clearfix" slot="user-name">刘某 <time style="font-size: 0.414814rem;color: #dadada;float: right;margin-right: 0.666666rem;font-weight: normal;"><span>下午</span><span>4:19</span></time></h5>
					<p style="font-size: 0.503703rem;color: #dadada;line-height: 0.592592rem;" slot="user-news"><span>在干啥？</span></p>
				</news>
				<news>
					<img src="http://pic3.zhimg.com/50/v2-280218dcc9db1a9108b867bd81b29745_hd.jpg" alt="" slot="user-img">
					<h5 style="font-size: 0.592592rem;line-height: 1.185185rem;" class="clearfix" slot="user-name">刘某 <time style="font-size: 0.414814rem;color: #dadada;float: right;margin-right: 0.666666rem;font-weight: normal;"><span>下午</span><span>4:19</span></time></h5>
					<p style="font-size: 0.503703rem;color: #dadada;line-height: 0.592592rem;" slot="user-news"><span>在干啥？</span></p>
				</news>
				<news>
					<img src="http://pic3.zhimg.com/50/v2-280218dcc9db1a9108b867bd81b29745_hd.jpg" alt="" slot="user-img">
					<h5 style="font-size: 0.592592rem;line-height: 1.185185rem;" class="clearfix" slot="user-name">刘某 <time style="font-size: 0.414814rem;color: #dadada;float: right;margin-right: 0.666666rem;font-weight: normal;"><span>下午</span><span>4:19</span></time></h5>
					<p style="font-size: 0.503703rem;color: #dadada;line-height: 0.592592rem;" slot="user-news"><span>在干啥？</span></p>
				</news>
			</div>
		</div>
	</div>
</template>
<script>
	
</script>
<style>
	
</style>