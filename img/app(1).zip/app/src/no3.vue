<template>
	<div>
		<headers>
			<span slot="tite">发现</span>
			<i class="iconfont" slot="icon1" style="float: right;margin-left: 1.481481rem;">&#xe6ac;</i>
			<i class="iconfont" slot="icon2" style="float: right;">&#xe63a;</i>
		</headers>
	</div>
</template>