<template>
	<div>
		<div v-for="i in type" style="border-bottom:1px solid #ccc;margin-top:20px;padding-bottom:10px;width:100%;overflow:hidden;">
			<div style="float:left; width:10%;"><img style="width:84px;height:112px;" :src="i.cover" alt=""></div>
			<div style="float:left;width:40%">
				<h3><a href="#/aaa/:">{{i.title}}</a></h3>
				<p>{{i.author}}</p>
				<span>{{i.desc}}</span>
				<p>{{i.tags}}</p>
			</div>
		</div>
	</div>
</template>
<script src="vue-resource.js"></script>
<script>
	export default {
  name: 'app',

  data () {
    return {
     	type:''
    }
  },
  created(){
    this.$http.get('http://read.xiaoshuo1-sm.com/novel/i.php',{params:{
      do: 'is_caterank',
    p: 1,
    page: 1,
    words: '',
    shuqi_h5: '',
    onlyCpBooks: 1,
    secondCate: '现代言情',
    sort: 'monthHot',
    _: 1577686974750

    }}).then((data)=>{
      console.log(data)
      this.type=data.body.data
      console.log(this.type)
    })
  },
}
</script>