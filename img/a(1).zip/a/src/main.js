import Vue from 'vue'
import router from './router'
import App from './App.vue'
import resource from 'vue-resource'
Vue.use(resource)
new Vue({
router,
  el: '#app',
  render: h => h(App)
})
