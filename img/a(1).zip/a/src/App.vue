<template>
  <div id="app">
      <div>
        <li>
          <a v-for="(i,$index) in arr" @click="index=$index" :class="index==$index?'a':''" :href="i.b" >{{i.a}}</a>
        </li>
      </div>
      <div>
        <li>
         <a v-for="(i,$index) in arr1" @click="index1=$index" :class="index1==$index?'a':''" :href="i.b">{{i.a}}</a>
        </li>
      </div>
      <div>
        <li>
         <a v-for="(i,$index) in arr2" @click="index2=$index" :class="index2==$index?'a':''" :href="i.b">{{i.a}}</a>
        </li>
      </div>
      <div>
        <router-view></router-view>
      </div>
  </div>
</template>

<script>
export default {
  name: 'app',
  
  data () {
    return {
      index:'',
      index1:'',
      index2:'',
      arr:[
        {
          a:'全部',
          b:'#/'
        },
        {
          a:'唯美童话',
          b:'#/no1/唯美童话'
        },
        {
          a:'虐文',
          b:'#/no1/悲情虐文'
        },
        {
          a:'网游',
          b:'#/no1/网络情缘'
        },
        {
          a:'总裁',
          b:'#/aaa/总裁'
        },
        {
          a:'宝宝',
          b:'#/aaa/宝宝'
        },
        {
          a:'爽文',
          b:'#/aaa/爽文'
        },
        {
          a:'宠文',
          b:'#/aaa/宠文'
        },
        {
          a:'腹黑',
          b:'#/aaa/腹黑'
        },
         {
          a:'情感',
          b:'#/aaa/情感'
        },
         {
          a:'现代',
          b:'#/aaa/现代'
        }
      ],
      arr1:[
       {
          a:'全部',
          b:'#/no1/1'
        },
         {
          a:'20万字',
          b:'#/no1/1'
        },
         {
          a:'20到100万字',
          b:'#/no1/2'
        },
         {
          a:'100万字以上',
          b:'#/no1/3'
        },
      ],
      arr2:[
         {
          a:'最新',
          b:'#/no1/唯美童话'
        },
         {
          a:'最热',
          b:'#/no1/唯美童话'
        },
         {
          a:'完结',
          b:'#/no1/唯美童话'
        },
      ]
    }
  },
 
  
}
</script>

<style>
*{
  margin:0;
  padding:0;
  text-decoration:none;
  list-style:none;
}
.a{
      color: #00c98d;

}
a{
  color:#333;
  font-size:14px;
  margin-right:35px;
}
li{
  width:100%;
  height:40px;
  border-bottom:1px solid #ccc;
  border-top:1px #ccc solid;
  line-height:40px;
}
</style>
